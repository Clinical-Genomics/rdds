#!/bin/bash

set -e

CASES_DIR=/home/tor.bjorgen/repos/cg/raredisease-ml/tmp/variant-rank-score/test_cases_modelscore_5a42dea
CASES_DIR=/home/tor.bjorgen/repos/cg/raredisease-ml/tmp/variant-rank-score/test_cases_filtervep_narrowclinfilter_5a42dea_no_clinvar_conflicting_uncertain
CASES_DIR=/home/tor.bjorgen/repos/cg/raredisease-ml/tmp/variant-rank-score/test_cases_narrowclin_nospidex

for dir in `ssh hasta find $CASES_DIR -type d`;
do
	if [ $dir == $CASES_DIR ]; then
		continue
	fi
	case_name=`basename $dir`
	mkdir -p $case_name
	scp -r hasta:$CASES_DIR/$case_name/*.png $case_name | true
done
